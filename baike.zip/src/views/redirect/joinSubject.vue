<template>
	<div style="margin:0 auto">未加入该专题,<a @click="join">立即加入</a></div>
</template>

<script>
export default {
	name:"joinSubject",
	methods:{
		join(){
			
		}
	}
}
</script>

