<template>
	<div style="margin:0 auto">该专题未被创建</div>
</template>

<script>
export default {
	name:"unCreatedSubject",
}
</script>
