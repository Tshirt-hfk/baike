<template>
	<myEditor></myEditor>
</template>

<script>
import myEditor from "../components/myEditor";
export default {
	name:"Test",
	components:{
		myEditor
	}
}
</script>
